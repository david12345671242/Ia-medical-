# 🏥 Chatbot Médical IA - Assistant Santé Intelligent

## Description

Application web complète avec **Flask** (backend) et **HTML/CSS/JS** (frontend) intégrant une **vraie IA médicale** basée sur Claude (Anthropic). L'IA peut répondre à n'importe quelle question médicale de manière approfondie et conversationnelle.

## ✨ Fonctionnalités

- **IA Réelle et Intelligente** : Utilise Claude AI pour des réponses authentiques et détaillées
- **Conversation Continue** : L'IA se souvient du contexte de la conversation
- **Tous Domaines Médicaux** : Anatomie, physiologie, pathologies, traitements, médicaments, etc.
- **Interface Moderne** : Design professionnel et responsive
- **Temps Réel** : Réponses instantanées de l'IA
- **Exemples Interactifs** : Questions suggérées pour démarrer

## 📋 Prérequis

- Python 3.7 ou supérieur
- Connexion internet (pour l'API Anthropic)

## 🚀 Installation et Démarrage

### 1. Installer les dépendances

```bash
pip install -r requirements.txt
```

### 2. Lancer l'application

```bash
python app.py
```

### 3. Ouvrir dans le navigateur

Ouvrez votre navigateur et accédez à :
```
http://localhost:5000
```

## 💡 Utilisation

1. **Poser une Question** : Tapez votre question médicale dans le champ de texte
2. **Cliquer sur Envoyer** : L'IA Claude va analyser et répondre
3. **Conversation Continue** : Vous pouvez poser des questions de suivi
4. **Nouvelle Conversation** : Cliquez sur "Nouvelle conversation" pour recommencer

## 🎯 Exemples de Questions

- "Quels sont les symptômes et traitements de l'hypertension artérielle ?"
- "Comment fonctionne le système immunitaire ?"
- "Explique-moi le diabète de type 2 et ses complications"
- "Quelles sont les différentes causes de maux de tête ?"
- "Comment traite-t-on une infection respiratoire ?"
- "Quels sont les effets secondaires de l'ibuprofène ?"

## 🔧 Architecture Technique

### Backend (Flask)
- `app.py` : Serveur Flask avec routes API
- Intégration API Anthropic Claude
- Gestion de l'historique des conversations
- Endpoints REST pour le chat

### Frontend (HTML/CSS/JS)
- Interface utilisateur moderne et responsive
- JavaScript pour les interactions en temps réel
- Design avec gradients et animations
- Support mobile et desktop

## 🤖 Intelligence Artificielle

L'application utilise **Claude Sonnet 4** d'Anthropic :
- **Modèle** : claude-sonnet-4-20250514
- **Capacités** : Raisonnement avancé, connaissances médicales approfondies
- **Contexte** : Mémorisation de la conversation pour des échanges naturels
- **Spécialisation** : Configuré comme assistant médical expert

## ⚠️ Avertissement Médical

Cette application est à **but éducatif et informatif uniquement**. Les informations fournies par l'IA ne remplacent pas une consultation médicale professionnelle. Consultez toujours un médecin pour un diagnostic ou traitement personnalisé.

## 📁 Structure du Projet

```
medical_chatbot/
│
├── app.py                  # Application Flask principale
├── requirements.txt        # Dépendances Python
├── README.md              # Ce fichier
│
└── templates/
    └── index.html         # Interface utilisateur
```

## 🌟 Points Forts

✅ **IA Authentique** : Pas de réponses pré-enregistrées, l'IA réfléchit vraiment
✅ **Conversations Naturelles** : Échanges fluides et contextuels
✅ **Réponses Détaillées** : Explications complètes et approfondies
✅ **Tous Sujets Médicaux** : Couvre l'ensemble du domaine médical
✅ **Interface Professionnelle** : Design moderne et agréable
✅ **Prêt à l'Emploi** : Fonctionne immédiatement après installation

## 📞 Support

Pour toute question ou problème, l'IA est conçue pour être patiente et pédagogique. N'hésitez pas à poser des questions de clarification ou à approfondir un sujet.

---

**Développé avec Flask, Claude AI et passion pour la santé ! 💙**
