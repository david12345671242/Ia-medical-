from flask import Flask, render_template, request, jsonify
import os
import json
from datetime import datetime

app = Flask(__name__)

# Stocker l'historique des conversations par session
conversations = {}

def get_ai_response(user_message, conversation_id):
    """
    Obtenir une réponse de l'IA Claude via l'API Anthropic
    """
    try:
        import requests
        
        # Récupérer ou initialiser l'historique de conversation
        if conversation_id not in conversations:
            conversations[conversation_id] = []
        
        # Ajouter le message de l'utilisateur à l'historique
        conversations[conversation_id].append({
            "role": "user",
            "content": user_message
        })
        
        # Construire les messages pour l'API
        messages = conversations[conversation_id].copy()
        
        # Appel à l'API Claude
        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "Content-Type": "application/json",
                "anthropic-version": "2023-06-01"
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 2000,
                "system": """Tu es un assistant médical expert et bienveillant. Tu possèdes des connaissances approfondies dans tous les domaines de la médecine : anatomie, physiologie, pathologie, pharmacologie, chirurgie, diagnostic, traitements, prévention, etc.

Tu dois :
- Répondre de manière détaillée et précise à toutes les questions médicales
- Adapter ton niveau de langage à l'utilisateur
- Expliquer les concepts complexes de façon claire
- Donner des informations complètes et actualisées
- Pouvoir discuter de cas cliniques, symptômes, traitements, médicaments
- Être capable d'avoir des échanges approfondis sur n'importe quel sujet médical
- Fournir des explications sur les mécanismes physiologiques et pathologiques
- Discuter des différentes options thérapeutiques et leurs avantages/inconvénients

IMPORTANT : 
- Toujours rappeler que tes informations sont à titre éducatif
- Encourager la consultation d'un professionnel de santé pour un diagnostic ou traitement personnalisé
- Ne jamais remplacer un avis médical professionnel
- Être empathique et rassurant tout en restant factuel

Réponds de manière naturelle, conversationnelle et professionnelle.""",
                "messages": messages
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            ai_message = data['content'][0]['text']
            
            # Ajouter la réponse de l'assistant à l'historique
            conversations[conversation_id].append({
                "role": "assistant",
                "content": ai_message
            })
            
            return ai_message
        else:
            return f"Désolé, une erreur s'est produite. L'API a retourné le code {response.status_code}. Assurez-vous que l'API Anthropic est accessible."
            
    except Exception as e:
        return f"Erreur lors de la communication avec l'IA : {str(e)}"

@app.route('/')
def home():
    """Page d'accueil"""
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    """Endpoint pour recevoir les messages et renvoyer les réponses de l'IA"""
    try:
        data = request.json
        user_message = data.get('message', '')
        conversation_id = data.get('conversation_id', 'default')
        
        if not user_message:
            return jsonify({'error': 'Message vide'}), 400
        
        # Obtenir la réponse de l'IA
        ai_response = get_ai_response(user_message, conversation_id)
        
        return jsonify({
            'response': ai_response,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/reset', methods=['POST'])
def reset_conversation():
    """Réinitialiser la conversation"""
    try:
        data = request.json
        conversation_id = data.get('conversation_id', 'default')
        
        if conversation_id in conversations:
            conversations[conversation_id] = []
        
        return jsonify({'message': 'Conversation réinitialisée'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🏥 CHATBOT MÉDICAL IA - Démarrage")
    print("="*60)
    print("\n📌 Le serveur démarre sur http://localhost:5000")
    print("📌 Ouvrez votre navigateur et accédez à cette adresse")
    print("\n💡 L'IA utilise Claude (Anthropic) pour des réponses intelligentes")
    print("💡 Vous pouvez poser n'importe quelle question médicale\n")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
