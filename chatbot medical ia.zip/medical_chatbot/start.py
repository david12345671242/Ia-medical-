#!/usr/bin/env python3
"""
Script de lancement du Chatbot Médical IA
"""
import os
import sys

print("\n" + "="*70)
print("🏥 CHATBOT MÉDICAL IA - Lancement")
print("="*70)
print("\n📌 Démarrage du serveur Flask...")
print("📌 L'application sera accessible sur : http://localhost:5000")
print("\n💡 L'IA utilise Claude (Anthropic) pour répondre à vos questions")
print("💡 Posez n'importe quelle question médicale et obtenez des réponses détaillées")
print("\n⚠️  IMPORTANT : Cette IA est à but éducatif. Consultez un médecin pour un diagnostic.")
print("\n" + "="*70 + "\n")

# Lancer l'application
os.system("python3 app.py")
